<?php

$settings['modules_enabled'] = array();

$settings['allow_registration'] = true;
$settings['registration_webmaster'] = "webmaster@example.com";
$settings['lang'] = 'en-GB';

$settings['leegmgr_enabled'] = true;
$settings['leegmgr_schedule'] = true;
$settings['leegmgr_extrastats'] = true;
$settings['leegmgr_cyanide'] = true;
$settings['leegmgr_cyanide_edition'] = 2;
$settings['leegmgr_botocs'] = true;

$settings['enable_pdf_logos'] = true;

