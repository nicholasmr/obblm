<?php

/*********************
 *   Prize types. Used by Prize class.
 *********************/

define('PRIZE_1ST',     1);
define('PRIZE_2ND',     2);
define('PRIZE_3RD',     3);
define('PRIZE_LETHAL',  4);
define('PRIZE_FAIR',    5);
define('PRIZE_LUCKY',   6);

?>
