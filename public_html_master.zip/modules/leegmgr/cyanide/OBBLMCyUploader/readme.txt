Instructions for using this application:
1. Edit the batch file to your own specification.
2. Run the batch file.
3. Play the game.
4. When the game ends the match will automatically upload.


This is written in Visual C# 2010 Express.
The zip functionality uses the shell32.dll, which would need to be referenced if you want to compile it.
TO run the executable the is required in the same directory or in a directory in the path statement, such as %windir%\system32.