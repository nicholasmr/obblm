<?php
$db_name = 'bbgetafe_obblm';
$db_user = 'bbgetafe_obblm';
$db_passwd = 'm~onE75F#xb251ML';
$rootpass = 'odt.xwing@gmail.com';
?>