<?php
// Log catagory types.
define('T_LOG_OTHER', 0);
define('T_LOG_GOLDBANK', 1);

define('LOG_HIST_LENGTH', 3); // Show log entries for this number of months back in time.
?>
