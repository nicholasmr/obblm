<?php

$_t_player_skills = 
'
DROP TABLE IF EXISTS "Player_Skills";
CREATE TABLE Player_Skills (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,idPlayer_Listing INTEGER ,idSkill_Listing INTEGER );
';

?>